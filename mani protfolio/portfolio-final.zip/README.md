# GADE MANI SHARAN REDDY - Portfolio

Personal portfolio website showcasing my skills, education, and projects.

## Features

- Responsive design
- Modern UI/UX
- Contact form
- Project showcase
- Social media links

## Tech Stack

- HTML5
- CSS3
- JavaScript
- Font Awesome Icons
- Google Fonts

## Live Demo

[View Portfolio](https://your-vercel-url.vercel.app)

## Contact

- Email: [gademanisharanreddy@gmail.com](mailto:gademanisharanreddy@gmail.com)
- Phone: +91 6300886928
- LinkedIn: [Profile](https://www.linkedin.com/in/g-mani-sharan-reddy-b2b702351)
- GitHub: [Profile](https://github.com/manisharan-deep)